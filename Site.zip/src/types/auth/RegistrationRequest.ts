export class RegistrationRequest {
    email: string;
    password: string;

    constructor() {
        this.email = '';
        this.password = '';
    }
}