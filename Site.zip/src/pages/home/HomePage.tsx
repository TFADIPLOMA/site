import { useStores } from "../../provider/MobxProvider";

const HomePage = () => {
  const {authStore} = useStores()
  return (
    <>
      <h2 className="page-title">
        Главная
      </h2>
    </>
  );
};

export default HomePage;