import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button, Card, Form, Image, Input, message, Tabs } from "antd";
import { useStores } from "../../provider/MobxProvider";
import Title from "antd/es/typography/Title";
import authService from "../../service/AuthService";
import { AxiosError } from "axios";
import { UserOutlined, LockOutlined, QrcodeOutlined } from '@ant-design/icons';


const LoginPage = () => {

    const navigate = useNavigate()
    const [loading, setLoading] = useState(false);
    const [tabKey, setTabKey] = useState("local");
    const [qrCode, setQrCode] = useState<string | null>(null);
    const onFinish = async (values: { email: string, password: string }) => {
        setLoading(true);
        try {
            authService.login(values.email, values.password).then((data) => {
                setLoading(false)
                navigate('/verify-email-code/'+values.email)
            }).catch(e => {
                if (e instanceof AxiosError) {
                    switch (e.status) {
                        case 404:
                            message.error("Пользователь не найден")
                            break;
                        case 401:
                            message.error("Неверный пароль")
                            break;
                        default:
                            message.error("Непредвиденная ошибка, попробуйте позже")
                            break;
                    }
                }
            });
        } catch (error) {
            console.error('Error:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (tabKey === 'qr') {
            authService.getQrCode().then(data => {
                const blob = new Blob([data], { type: 'image/png' });
                const url = URL.createObjectURL(blob);
                setQrCode(url);
            })
        }
    }, [tabKey])



    return (
        <>
            <Title level={2}>Вход</Title>

            <Tabs
                onChange={(key) => setTabKey(key)}
                activeKey={tabKey}
                items={[
                    {
                        key: 'local',
                        label: "Войти через пароль",
                        children: <>
                            <Card style={{ maxWidth: 500 }}>
                                <Form
                                    name="login"
                                    initialValues={{ remember: true }}
                                    onFinish={onFinish}
                                >
                                    <Form.Item
                                        name="email"
                                        rules={[{ required: true, message: 'Пожалуйста, введите Email!' }]}
                                    >
                                        <Input
                                            prefix={<UserOutlined className="site-form-item-icon" />}
                                            placeholder="Email"
                                        />
                                    </Form.Item>
                                    <Form.Item
                                        name="password"
                                        rules={[{ required: true, message: 'Пожалуйста, введите пароль!' }]}
                                    >
                                        <Input
                                            prefix={<LockOutlined className="site-form-item-icon" />}
                                            type="password"
                                            placeholder="Пароль"
                                        />
                                    </Form.Item>

                                    <Form.Item>
                                        <Button type="primary" htmlType="submit" loading={loading} block>
                                            Войти
                                        </Button>
                                    </Form.Item>

                                    <Form.Item>
                                        Если у вас нет аккаунта, <Link to="/auth/register">зарегистрируйтесь</Link>
                                    </Form.Item>

                                </Form>
                            </Card>
                        </>
                    },
                    {
                        key: 'qr',
                        label: "Войти через QR-код",
                        children: <>
                            <p>
                                Пожалуйста отсканируйте QR-код с помощью приложения Two Factor Auth5789
                            </p>

                            {qrCode && <Image src={qrCode} width={300}/>}
                        </>
                    }
                ]}
            />


        </>
    );
};

export default LoginPage;